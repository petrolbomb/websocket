package org.jbp.model2.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ReplyController {

}
