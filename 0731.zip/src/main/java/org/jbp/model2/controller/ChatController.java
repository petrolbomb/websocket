package org.jbp.model2.controller;

import java.util.Map;

import org.jbp.model2.vo.Protocol;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ChatController {
	
	private Map<String, Protocol> users;

	public void setUsers(Map<String, Protocol> users) {
		this.users = users;
	}
	
	@RequestMapping(value="/main",method=RequestMethod.GET)
	public void main() {
		
	}
	
	@MessageMapping("/hello") // 받는곳
	@SendToUser(value="/queue/join") // 보내는곳
	public Protocol ss(Protocol protocol,SimpMessageHeaderAccessor accessor) throws Exception {
		
		System.out.println("/hello 드러옴!");
		//template.convertAndSendToUser(accessor.getUser().getName(),"/queue/join",protocol);
		
		// Thread.sleep(100); // delay
		protocol.setUser(users.get(accessor.getSessionId()));
		
		return protocol;
	}
	
	@MessageMapping("/msg") // 받는곳
	@SendTo("/topic/msg") // 보내는곳
	public Protocol asdfs(Protocol protocol, SimpMessageHeaderAccessor accessor) throws Exception {
		
		System.out.println("/msg 들어옴!");
		
		protocol.setUser(users.get(accessor.getSessionId()));
		return protocol;
		// Thread.sleep(100); // delay
	}

}
