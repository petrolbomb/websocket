package org.jbp.model2.listener;

import java.util.Map;

import org.jbp.model2.vo.Protocol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

@Component
public class StompListener {
	
	@Autowired
	private SimpMessagingTemplate template;
	
	private Map<String, Protocol> users;
	
	public void setUsers(Map<String, Protocol> users) {
		this.users = users;
	}
	
	@EventListener
	private void handleSessionConnected(SessionConnectEvent event) {
		StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
		
		String nickname = accessor.getNativeHeader("nickname").get(0);
		String profile = accessor.getNativeHeader("profile").get(0);
		Protocol user = new Protocol(nickname, profile, accessor.getSessionId());
		
		users.put(accessor.getSessionId(),user);
		
		System.out.println("유저수 : " + users.size());
		
		//System.out.println(accessor.getUser().getName());
		
		template.convertAndSend("/topic/join",user);
		
	}
	
	@EventListener
	private void handleSessionDisconnect(SessionDisconnectEvent event) {
		StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
		
		Protocol user = users.get(accessor.getSessionId());
		users.remove(accessor.getSessionId());
		
		System.out.println("유저수 : " + users.size());
		
		template.convertAndSend("/topic/leave",user);
	}

}
